import dataiku

def existing_recipe(output_name, input_name):
    project = dataiku.api_client().get_default_project()
    if output_name not in [dataset.name for dataset in project.list_datasets(as_type="objects")]:
        return None
    
    output_dataset = project.get_dataset(output_name)
    recipe_dict = next((recipe for recipe in output_dataset.get_usages() if recipe["type"] == "RECIPE_OUTPUT"), None)
    if recipe_dict is not None:
        recipe = project.get_recipe(recipe_dict["objectId"])
        if recipe.get_settings().has_input(input_name):
            return recipe
        else:
            raise ValueError("Cannot create a recipe if the output dataset is already used as an output")
    return None


def create_prepare_recipe(input_name, output_name, connection_id):
    project = dataiku.api_client().get_default_project()
    print("AZERY")
    recipe = existing_recipe(output_name, input_name)
    if recipe is not None:
        return recipe
    print("FDSGDFSGSDFG")
    prepare_recipe = project.new_recipe("prepare")
    prepare_recipe.with_input(input_name)
    prepare_recipe.with_new_output(output_name, connection_id)
    recipe = prepare_recipe.create()
    return recipe


def edit_prepare_recipe(recipe, output_name, renaming_map, schema_map=None, run=True):
    project = dataiku.api_client().get_default_project()
    
    # recipe preparation settings
    recipe_settings = recipe.get_settings()
    json_payload = recipe_settings.get_json_payload()
    json_payload["steps"] = []

    recipe_settings.add_processor_step(
        type="ColumnsSelector",
        params={
            'appliesTo': 'COLUMNS',
            'columns': list(renaming_map.keys()),
            'keep': True
        })

    recipe_settings.add_processor_step(
        type="ColumnRenamer",
        params={
            'renamings': [{'from': key, 'to': value} for key, value in renaming_map.items()]
        })

    recipe_settings.save()
    
    if schema_map is not None:
        output_dataset = project.get_dataset(output_name)
        old_schema = output_dataset.get_schema()
        new_schema = [
            column_schema
            if column_schema["name"] not in schema_map
            else {"name": column_schema["name"], "type": schema_map[column_schema["name"]]}
            for column_schema in old_schema["columns"]
        ]
        output_dataset.set_schema({'columns': new_schema})
        
    required_updates = recipe.compute_schema_updates()
    if required_updates.any_action_required():
        required_updates.apply()
        
    if run:
        recipe.run()
        
        
        
def create_join_recipe(input_name_0, input_name_1, output_name, connection_id):
    project = dataiku.api_client().get_default_project()
    
    recipe = existing_recipe(output_name, input_name_0)
    if recipe is not None:
        return recipe
    
    # general recipe definition
    join_recipe = project.new_recipe("join")
    join_recipe.with_input(input_name_0)
    join_recipe.with_input(input_name_1)
    join_recipe.with_new_output(output_name, connection_id)
    recipe = join_recipe.create()
    return recipe

def edit_join_recipe(recipe, input_column_0, input_column_1, run=True):
    # recipe preparation settings
    recipe_settings = recipe.get_settings()
    json_payload = recipe_settings.get_json_payload()
    json_payload["joins"] = []

    join = recipe_settings.add_join(join_type='LEFT', input1=0, input2=1)
    recipe_settings.add_condition_to_join(join, type='EQ', column1=input_column_0, column2=input_column_1)
    recipe_settings.save()

    required_updates = recipe.compute_schema_updates()
    if required_updates.any_action_required():
        required_updates.apply()
    
    if run:
        recipe.run()
        
        
def create_topn_recipe(input_name, output_name, connection_id):
    project = dataiku.api_client().get_default_project()
    
    recipe = existing_recipe(output_name, input_name)
    if recipe is not None:
        return recipe
    
    if output_name not in [dataset.name for dataset in project.list_datasets(as_type="objects")]:
        builder = project.new_managed_dataset(output_name)
        builder.with_store_into(connection_id)
        builder.create()
    
    topn_recipe = project.new_recipe("topn")
    topn_recipe.with_input(input_name)
    topn_recipe.with_output(output_name)
    recipe = topn_recipe.create()
    return recipe

def edit_topn_recipe(recipe, top_n, ranking_column, run=True):
    # recipe preparation settings
    recipe_settings = recipe.get_settings()
    json_payload = recipe_settings.get_json_payload()
    
    json_payload["firstRows"] = top_n
    json_payload["keys"] = ["user_id"]
    json_payload["orders"] = [{'column': ranking_column, 'desc': True}]
    json_payload["retrievedColumns"] = ['item_id', "user_id", ranking_column]
    
    recipe_settings.set_json_payload(json_payload)
    recipe_settings.save()

    required_updates = recipe.compute_schema_updates()
    if required_updates.any_action_required():
        required_updates.apply()
    
    if run:
        recipe.run()

def move_datasets_to_zone(dataset_names, zone_id):
    project = dataiku.api_client().get_default_project()
    for dataset_name in dataset_names:
        project.get_dataset(dataset_name).move_to_zone(zone_id)


