FLOW_INPUTS = ["input_samples", "input_users"]

RECIPE_TYPES_FOR_ENGINE_SWITCH = ["join", "shaker", "vstack", "prediction_scoring", "split"]