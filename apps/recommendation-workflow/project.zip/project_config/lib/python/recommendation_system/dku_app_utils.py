import dataiku
from dataikuapi.dss.dataset import SQLDatasetSettings




        
def apply_changes_before_run(project, recipe, run=True):    
#     input_dataset = project.get_dataset("input")
#     input_dataset_settings = input_dataset.get_settings()
    
#     dataset_names = [dataset["ref"] for dataset in recipe.get_settings().get_recipe_outputs()["main"]["items"]]
#     
#     for dataset_name in dataset_names:
#         dataset_settings = project.get_dataset(dataset_name).get_settings()
#         if isinstance(dataset_settings, SQLDatasetSettings):
#             dataset_settings.settings["params"]["connection"] = input_dataset_settings.settings["params"]["connection"]
#             dataset_settings.settings["type"] = input_dataset_settings.settings["type"]
#             dataset_settings.settings["params"]["schema"] = input_dataset_settings.settings["params"]["schema"]
#             dataset_settings.save()
    
    required_updates = recipe.compute_schema_updates()
    if required_updates.any_action_required():
        required_updates.apply()
        





                 

        



def copy_schema(input_name, output_name):
    project = dataiku.api_client().get_default_project()
    input_schema = project.get_dataset(input_name).get_schema()["columns"]
    project.get_dataset(output_name).set_schema({"columns": input_schema})
        
def create_sync_recipe(input_name, output_name):
    project = dataiku.api_client().get_default_project()    
  
    sync_recipe = project.new_recipe("sync")
    sync_recipe.with_input(input_name)
    sync_recipe.with_output(output_name)
    recipe = sync_recipe.create()
    return recipe
    


